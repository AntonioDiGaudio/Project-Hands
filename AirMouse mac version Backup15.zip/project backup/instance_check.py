# instance_check.py
import os
import tempfile
import fcntl

lock_file_path = os.path.join(tempfile.gettempdir(), 'airmouse.lock')
_lock_file = None

def is_already_running():
    global _lock_file
    try:
        _lock_file = open(lock_file_path, 'w')
        fcntl.flock(_lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return False, _lock_file
    except (IOError, BlockingIOError):
        return True, None
