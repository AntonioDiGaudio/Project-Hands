"""
Modulo principale dell'applicazione AirMouse.
Gestisce l'inizializzazione e l'esecuzione dell'applicazione.
"""

import cv2
import threading
import time
import platform
from webcam_manager import WebcamManager
from hand_tracker import HandTracker
from mouse_controller import MouseController
from settings_gui import create_settings_gui
from shared_state import set_running, get_running
import config
from gesture_recognizer import GestureRecognizer

class AirMouseApp:
    """
    Classe principale dell'applicazione AirMouse.
    Gestisce l'inizializzazione e l'esecuzione dell'applicazione.
    """

    def __init__(self):
        """Inizializza l'applicazione AirMouse."""
        self.webcam_manager = WebcamManager()
        self.hand_tracker = HandTracker(config)
        self.mouse_controller = MouseController(config)
        self.gesture_recognizer = GestureRecognizer(config)
        self.preferred_hand = "Right"
        self.drag_mode_enabled = True
        self.enable_right_click = True
        self.slide_cooldown = 0.0
        self.cap = None

    def initialize(self):
        """
        Inizializza l'applicazione selezionando la webcam.
        Restituisce True se ok, False altrimenti.
        """
        try:
            selected_cam = self.webcam_manager.select_camera_gui()
            self.cap = self.webcam_manager.open_camera(selected_cam)
            set_running(True)
            return True
        except Exception as e:
            print(f"Errore durante l'inizializzazione: {e}")
            return False

    def run(self):
        """Ciclo principale: cattura frame, riconosce gesture, muove il mouse."""
        system = platform.system()
        show_gui = (system != "Darwin")

        if self.cap is None:
            print("Webcam non inizializzata")
            return

        if show_gui:
            cv2.namedWindow("Hand Mouse Control", cv2.WINDOW_NORMAL)

        while get_running():
            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.01)
                continue

            frame = cv2.flip(frame, 1)
            frame, results = self.hand_tracker.find_hands(frame, draw=True)
            h, w, _ = frame.shape
            hands_data = self.hand_tracker.find_positions(frame, results)
            right_points = hands_data.get("Right")
            left_points = hands_data.get("Left")
            right_state = self.hand_tracker.fingers_up(right_points) if right_points else None
            left_state = self.hand_tracker.fingers_up(left_points) if left_points else None

            # Controllo del cursore con mano destra
            if right_points and right_state and self.preferred_hand == "Right":
                ix, iy = right_points[8]
                px, py = right_points[4]
                dist = self.hand_tracker.distance_between_points((ix, iy), (px, py))
                if not self.gesture_recognizer.should_block_cursor(dist):
                    self.mouse_controller.move_cursor(ix, iy, w, h)
                self.mouse_controller.handle_click(dist, self.drag_mode_enabled, self.enable_right_click, right_state[3])

            # Slide con mano sinistra
            if left_points and left_state:
                if sum(left_state) == 0 and time.time() - self.slide_cooldown >= config.slide_cooldown_time:
                    x0, y0 = left_points[0]
                    margin_x = w * config.overscan_x
                    margin_y = h * config.overscan_y
                    direction = "center"
                    if y0 < margin_y:
                        direction = "up"
                    elif y0 > h - margin_y:
                        direction = "down"
                    elif x0 < margin_x:
                        direction = "left"
                    elif x0 > w - margin_x:
                        direction = "right"
                    if direction != "center":
                        self.mouse_controller.perform_slide(direction)
                        self.slide_cooldown = time.time()

            # Zoom con entrambe le mani
            if right_points and left_points and right_state and left_state:
                zoom_active = self.hand_tracker.check_zoom_gesture(right_state, left_state)
                distance = self.hand_tracker.distance_between_points(right_points[8], left_points[8])
                self.mouse_controller.handle_zoom(distance, zoom_active)
            else:
                self.mouse_controller.last_zoom_distance = None
                self.mouse_controller.zoom_distances = []

            if show_gui:
                # Overlay delle impostazioni
                overlay = frame.copy()
                cv2.rectangle(overlay, (10, 10), (310, 350), (0, 0, 0), -1)
                config_values = [
                    f"Sensibilità: {config.alpha_smooth:.2f}",
                    f"Velocità cursore: {config.cursor_speed_multiplier:.2f}",
                    f"Overscan X: {config.overscan_x:.2f}",
                    f"Overscan Y: {config.overscan_y:.2f}",
                    f"Soglia click: {config.click_distance_threshold:.1f}",
                    f"Cooldown click: {config.click_cooldown:.2f}s",
                    f"Soglia zoom: {config.zoom_threshold:.1f}",
                    f"Cooldown zoom: {config.zoom_cooldown_time:.2f}s",
                    f"Smoothing zoom: {config.zoom_smooth_factor:.1f}",
                    f"Distanza max zoom: {config.zoom_max_distance:.1f}",
                    f"Cooldown slide: {config.slide_cooldown_time:.3f}s",
                    f"Confidenza rilevamento: {config.min_detection_confidence:.2f}",
                    f"Confidenza tracking: {config.min_tracking_confidence:.2f}",
                    f"Complessità modello: {config.model_complexity}",
                    f"Risoluzione: {config.camera_width}x{config.camera_height}",
                    f"Accel. hardware: {'Sì' if config.use_hardware_acceleration else 'No'}"
                ]
                for i, text in enumerate(config_values):
                    cv2.putText(overlay, text, (15, 30 + i * 20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)

                cv2.imshow("Hand Mouse Control", frame)
                if cv2.waitKey(1) == 27:
                    set_running(False)
            else:
                time.sleep(0.01)

        if show_gui:
            cv2.destroyAllWindows()
        self.terminate()

    def terminate(self):
        """Chiude l'applicazione e rilascia le risorse."""
        try:
            if self.cap:
                self.webcam_manager.release_camera()
        except:
            pass
        set_running(False)

def main():
    """Funzione principale per avviare l'applicazione."""
    app = AirMouseApp()
    if app.initialize():
        # Avvia il ciclo di riconoscimento in thread
        recognition_thread = threading.Thread(target=app.run, daemon=True)
        recognition_thread.start()
        # Mostra GUI impostazioni (sul thread principale, macOS-safe)
        create_settings_gui()
        # Al termine della GUI, ferma il ciclo
        set_running(False)
        recognition_thread.join()
        app.terminate()
    else:
        print("Impossibile inizializzare l'applicazione")

if __name__ == "__main__":
    main()
