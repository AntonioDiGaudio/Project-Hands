import cv2
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox
from shared_state import get_running, set_running
from gui_theme import GUI_FONT, GUI_BG_COLOR, GUI_FG_COLOR, GUI_BUTTON_BG, GUI_BUTTON_FG, GUI_HIGHLIGHT_COLOR, GUI_FONT_BOLD_TITLE
import config
import platform
import re

class WebcamManager:
    def __init__(self):
        self.selected_camera = None
        self.cap = None

    def get_camera_names(self):
        camera_dict = {}
        system = platform.system()
        if system == "Linux":
            result = subprocess.run(
                ["v4l2-ctl", "--list-devices"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            output = result.stdout
            name = ""
            for line in output.splitlines():
                line = line.strip()
                if not line:
                    continue
                if not line.startswith("/dev"):
                    name = line
                elif line.startswith("/dev/video"):
                    idx = int(line.replace("/dev/video", "").strip())
                    camera_dict[idx] = name
            return camera_dict
        elif system == "Darwin":
            result = subprocess.run(
                ["ffmpeg", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            for line in result.stderr.splitlines():
                m = re.search(r"\[AVFoundation input device @ .+\] \[(\d+)\] (.+)", line)
                if m:
                    camera_dict[int(m.group(1))] = m.group(2)
            return camera_dict
        else:
            return {}

    def list_available_cameras(self, max_cams=5, stop_event=None):
        found = []
        camera_names = self.get_camera_names()
        max_cams = min(max_cams, len(camera_names)) if camera_names else max_cams
        threads = []
        for i in range(max_cams):
            if stop_event and stop_event.is_set():
                break
            t = threading.Thread(target=self.try_camera, args=(i, found, camera_names))
            t.start()
            threads.append(t)
        for t in threads:
            t.join(timeout=1.5)
        return found

    def try_camera(self, idx, found, camera_names):
        if self.cap is not None and self.cap.isOpened():
            return
        try:
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                found.append((idx, camera_names.get(idx, f"Camera {idx}")))
                cap.release()
        except Exception:
            pass

    def open_camera(self, camera_index=None):
        if camera_index is None:
            raise ValueError("Nessuna webcam selezionata")
        self.cap = cv2.VideoCapture(camera_index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.camera_width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.camera_height)
        return self.cap

    def select_camera_gui(self):
        if not get_running():
            return None
        selected_index = []
        stop_search = threading.Event()

        def on_select(i):
            nonlocal selected_index
            try:
                test_cap = cv2.VideoCapture(i)
                if not test_cap.isOpened():
                    messagebox.showerror("Errore", f"Impossibile aprire la webcam #{i}.")
                    return
                test_cap.release()
                selected_index.append(i)
                stop_search.set()
                root.destroy()
            except Exception as e:
                messagebox.showerror("Errore", f"Impossibile aprire la webcam #{i}. Dettagli errore: {str(e)}")

        def search_and_show():
            label.config(text="Ricerca webcam in corso...")
            cancel_btn.config(state=tk.NORMAL)
            def search_thread():
                cameras = self.list_available_cameras(stop_event=stop_search)
                if not cameras and not stop_search.is_set():
                    root.after(0, lambda: label.config(text="Nessuna webcam trovata."))
                    return
                if not stop_search.is_set():
                    root.after(0, lambda: show_cameras(cameras))
            threading.Thread(target=search_thread, daemon=True).start()

        def show_cameras(cameras):
            label.config(text="Seleziona una webcam:")
            for widget in frame.winfo_children():
                widget.destroy()
            for idx, cam_name in cameras:
                btn = tk.Button(
                    frame,
                    text=cam_name,
                    command=lambda i=idx: on_select(i),
                    font=GUI_FONT,
                    bg=GUI_BUTTON_BG,
                    fg=GUI_BUTTON_FG,
                    activebackground=GUI_HIGHLIGHT_COLOR,
                    relief="flat"
                )
                btn.pack(pady=5, padx=10, fill='x')

        def on_close():
            stop_search.set()
            set_running(False)
            root.destroy()
            raise SystemExit("Selezione webcam annullata dall'utente")

        root = tk.Tk()
        root.title("AirMouse")
        root.geometry("450x450")
        root.configure(bg=GUI_BG_COLOR)
        root.resizable(False, False)
        root.protocol("WM_DELETE_WINDOW", on_close)
        label = tk.Label(root, text="Ricerca webcam in corso...", font=GUI_FONT_BOLD_TITLE, bg=GUI_BG_COLOR, fg=GUI_FG_COLOR)
        label.pack(pady=10)
        frame = tk.Frame(root, bg=GUI_BG_COLOR)
        frame.pack(expand=True, fill='both')
        cancel_btn = tk.Button(
            root,
            text="Annulla",
            command=on_close,
            font=GUI_FONT,
            bg=GUI_BUTTON_BG,
            fg=GUI_BUTTON_FG,
            activebackground=GUI_HIGHLIGHT_COLOR,
            relief="flat",
            state=tk.DISABLED
        )
        cancel_btn.pack(pady=8, padx=40, fill='x')
        root.after(100, search_and_show)
        root.mainloop()
        if not selected_index:
            raise SystemExit("Nessuna webcam selezionata.")
        self.selected_camera = selected_index[0]
        return self.selected_camera

    def release_camera(self):
        if self.cap is not None and self.cap.isOpened():
            self.cap.release()
            self.cap = None