# main.py
import os
import sys
import tempfile
import logging
from instance_check import is_already_running
from app import main

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler()]
    )
    return logging.getLogger('AirMouse')

if __name__ == "__main__":
    logger = setup_logging()
    already_running, lock_handle = is_already_running()
    if already_running:
        logger.error("Un'altra istanza di AirMouse è già in esecuzione.")
        sys.exit(1)
    try:
        logger.info("Avvio di AirMouse...")
        main()
    except Exception as e:
        logger.exception(f"Errore durante l'esecuzione: {e}")
    finally:
        if lock_handle:
            try:
                lock_handle.close()
                os.remove(os.path.join(tempfile.gettempdir(), 'airmouse.lock'))
            except Exception:
                pass
